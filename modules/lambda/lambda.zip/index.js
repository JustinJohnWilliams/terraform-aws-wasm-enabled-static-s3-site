exports.handler = (event, context, callback) => {
    const response = event.Records[0].cf.response;
    const headers = response.headers;

    // Set the new headers
    headers['cross-origin-opener-policy'] = [{ key: 'Cross-Origin-Opener-Policy', value: 'same-origin' }];
    headers['cross-origin-embedder-policy'] = [{ key: 'Cross-Origin-Embedder-Policy', value: 'require-corp' }];

    callback(null, response);
};
